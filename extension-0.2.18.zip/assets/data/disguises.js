"use strict";

var Disguises = (function() { 

var data = 
{"glasses-tape":{"title":"Second-hand glasses","name":"glasses-tape","type":"glasses","level":"0","ext":".png"},"glasses-sun-slot-green":{"title":"Green 80's sunglasses","name":"glasses-sun-slot-green","type":"glasses","level":"5","ext":".png"},"glasses-sherlock":{"title":"Sherlock","name":"glasses-sherlock","type":"glasses","level":"10","ext":".png"},"mask-carnival-pink":{"title":"Pink carnival","name":"mask-carnival-pink","type":"mask","level":"15","ext":".png"},"glasses-sun-green":{"title":"Green sunglasses","name":"glasses-sun-green","type":"glasses","level":"20","ext":".png"},"glasses-groucho":{"title":"Groucho","name":"glasses-groucho","type":"glasses","level":"25","ext":".png"},"mask-pirate-black":{"title":"Pirate","name":"mask-pirate-black","type":"mask","level":"30","ext":".png"},"glasses-sun-slot-orange":{"title":"Orange 80's sunglasses","name":"glasses-sun-slot-orange","type":"glasses","level":"35","ext":".png"},"glasses-binoculars":{"title":"Binoculars","name":"glasses-binoculars","type":"glasses","level":"40","ext":".png"},"glasses-sun-hearts-red":{"title":"Heart sunglasses","name":"glasses-sun-hearts-red","type":"glasses","level":"45","ext":".png"},"glasses-sun-slot-pink":{"title":"Pink 80's sunglasses","name":"glasses-sun-slot-pink","type":"glasses","level":"50","ext":".png"},"glasses-sun-future":{"title":"Futuristic sunglasses","name":"glasses-sun-future","type":"glasses","level":"55","ext":".png"},"glasses-sun-sunset":{"title":"Sunset sunglasses","name":"glasses-sun-sunset","type":"glasses","level":"60","ext":".png"},"glasses-3D":{"title":"3D glasses","name":"glasses-3D","type":"glasses","level":"80","ext":".png"}}; 

return { data: data }; 

})(); 
