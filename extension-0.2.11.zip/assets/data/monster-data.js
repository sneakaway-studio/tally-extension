"use strict";

var MonsterData = (function() {

	return {
		dataById: MonstersById.data,
		// slugsById:slugsById,
		idsByTag: MonstersByTag.data
	};

})();
