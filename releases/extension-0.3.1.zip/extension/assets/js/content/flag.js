"use strict";

/*  FLAG
 ******************************************************************************/

window.Flag = (function () {
	// PRIVATE

	let DEBUG = Debug.ALL.Flag;





	/**
	 *	Check for new login / dashboard activity - to start (or continue) syncing to server
	 */
	async function checkForDashboardLogin() {
		try {
			// always allow unless mode disabled
			if (T.tally_options.gameMode === "disabled") return;

			// if they are already loggedin then return
			if (T.tally_meta.userLoggedIn) return;

			// only continue if user is on dashboard
			if (!Page.data.actions.onDashboard) return;

			console.log("🚩 Flag.checkForDashboardLogin() -> ON DASHBOARD");

			// update tally_meta in content and background - !IMPORTANT OR BACKGROUND WON'T CONTACT SERVER
			T.tally_meta.userLoggedIn = true;
			TallyStorage.saveData("tally_meta", T.tally_meta);

			// user just connected their account
			if (!Page.data.actions.checkForDashboardLoginCalled) {
				// so return true to interrupt startup flow
				Page.data.actions.checkForDashboardLoginCalled = true;
				return true;
			}
			// extension just reloaded data so let Progress show game events
			else Progress.dashboardLogin();

		} catch (err) {
			console.error(err);
		}
	}


	/**
	 *	Check for data reset on dashboard
	 */
	async function checkForAccountReset(what = "all") {
		try {
			// only allow if serverOnline
			if (!Page.data.mode.serverOnline) return;
			// don't allow if mode disabled
			if (T.tally_options.gameMode === "disabled") return;

			// only proceed if user is on dashboard and account reset flag elements exist
			if (!Page.data.actions.onDashboard || $(".tallyFlags").length < 1 && $("#resetUserAccountSuccess").length < 1) return;
			if (DEBUG) console.log("🚩 Flag.checkForAccountReset() resetUserAccountSuccess FLAG FOUND");

			// user just reset their account data
			if (!Page.data.actions.checkForAccountResetCalled) {
				// so return true to interrupt startup flow
				Page.data.actions.checkForAccountResetCalled = true;
				return true;
			}
			// extension just reloaded data so let Progress show game events
			else Progress.resetUserAccount();

		} catch (err) {
			console.error(err);
		}
	}







	/**
	 *	Check for flags from server
	 */
	function checkFromServer() {
		try {
			// are there serverFlags?
			if (!FS_Object.prop(T.tally_user.serverFlags) || FS_Object.isEmpty(T.tally_user.serverFlags)) return;
			if (DEBUG) console.log("🧰 TallyMain.checkForServerFlags() 🚩", T.tally_user.serverFlags);
			// address individual serverFlags...

			// SERVER SAYS: we have leveled up!
			if (FS_Object.prop(T.tally_user.serverFlags.levelUp)) {
				// make sure we have this flag in GameData
				if (!FS_Object.prop(GameData.serverFlags.levelUp))
					return console.warn("Flag does not exist in GameData.");
				// // update stats
				// Stats.reset("tally");
				// tell user
				setTimeout(function () {
					Dialogue.showStr(GameData.serverFlags.levelUp.dialogue, GameData.serverFlags.levelUp.mood);
					// remove flag once handled
					delete T.tally_user.serverFlags.levelUp;
				}, 300);
			}
			// // SERVER SAYS: we have received a new attack
			// // might do this locally instead
			// if (FS_Object.prop(T.tally_user.serverFlags.newAttack)) {
			// 	// remove flag once handled
			// }

		} catch (err) {
			console.error(err);
		}
	}





	// PUBLIC
	return {
		checkForDashboardLogin: checkForDashboardLogin,
		checkForAccountReset: checkForAccountReset,
		checkFromServer: checkFromServer
	};
})();
