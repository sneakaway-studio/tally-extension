"use strict";

var ConsumableData = (function() {

    let DEBUG = Debug.ALL.ConsumableData;

	return {
		data: Consumables.data
	};

})();
