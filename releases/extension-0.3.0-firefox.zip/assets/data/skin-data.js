"use strict";

var SkinData = (function() {

    let DEBUG = Debug.ALL.SkinData;

	return {
		data: Skins.data
	};

})();
