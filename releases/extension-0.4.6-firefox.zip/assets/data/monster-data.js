"use strict";

window.MonsterData = (function() {

	return {
		dataById: MonstersById.data,
		// slugsById:slugsById,
		idsByTag: MonstersByTag.data
	};

})();
