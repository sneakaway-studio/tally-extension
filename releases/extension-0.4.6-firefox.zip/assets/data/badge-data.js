"use strict";

var BadgeData = (function() {

    let DEBUG = Debug.ALL.BadgeData;

	return {
		data: Badges.data
	};

})();
