"use strict";

var Onboarding = (function() {
	// PRIVATE
	let DEBUG = Debug.ALL.Onboarding;

	// check status of most recent
	function check() {
		try {

		} catch (err) {
			console.error(err);
		}

	}


	// show a new chapter,
	function show(_chapter) {
		try {

		} catch (err) {
			console.error(err);
		}
	}



	// PUBLIC
	return {

	};
}());
