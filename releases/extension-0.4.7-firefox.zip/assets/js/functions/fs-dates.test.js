"use strict";

/**
 *	Import revealing module pattern as ES6 module and test using jest
 * 	run: npm test
 */

// placeholder so tests pass
// NOTE: can't get moment to load and probably should remove in future versions
test('placeholder', () => {
	expect(1 + 1).toEqual(2);
});


// // import module
// const Mod = require('./fs-dates.js');
//
// //1.
//
// // get current time
// test('gets current time', () => {
//   const currentTime = Mod.time()
// 	expect(currentTime).toContain(":");
// });
