"use strict";

var DisguiseData = (function() {

    let DEBUG = Debug.ALL.DisguiseData;

	return {
		data: Disguises.data,
    	dataByLevel: DisguisesByLevel.data
	};

})();
