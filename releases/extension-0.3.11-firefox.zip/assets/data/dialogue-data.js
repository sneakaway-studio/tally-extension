"use strict";

var DialogueData = (function() {

    let DEBUG = Debug.ALL.DialogueData;

	return {
		data: Dialogues.data
	};

})();
