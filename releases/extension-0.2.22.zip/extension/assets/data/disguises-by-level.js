"use strict";

var DisguisesByLevel = (function() { 

var data = 
{"0":{"title":"Second-hand glasses","name":"glasses-tape","type":"glasses","level":"0","ext":".png"},"5":{"title":"Green 80's sunglasses","name":"glasses-sun-slot-green","type":"glasses","level":"5","ext":".png"},"10":{"title":"3D glasses","name":"glasses-3D","type":"glasses","level":"10","ext":".png"},"15":{"title":"Pink carnival","name":"mask-carnival-pink","type":"mask","level":"15","ext":".png"},"20":{"title":"Green sunglasses","name":"glasses-sun-green","type":"glasses","level":"20","ext":".png"},"25":{"title":"Sherlock","name":"glasses-sherlock","type":"glasses","level":"25","ext":".png"},"30":{"title":"Pirate","name":"mask-pirate-black","type":"mask","level":"30","ext":".png"},"35":{"title":"Orange 80's sunglasses","name":"glasses-sun-slot-orange","type":"glasses","level":"35","ext":".png"},"40":{"title":"Binoculars","name":"glasses-binoculars","type":"glasses","level":"40","ext":".png"},"45":{"title":"Heart sunglasses","name":"glasses-sun-hearts-red","type":"glasses","level":"45","ext":".png"},"50":{"title":"Pink 80's sunglasses","name":"glasses-sun-slot-pink","type":"glasses","level":"50","ext":".png"},"55":{"title":"Futuristic sunglasses","name":"glasses-sun-future","type":"glasses","level":"55","ext":".png"},"60":{"title":"Sunset sunglasses","name":"glasses-sun-sunset","type":"glasses","level":"60","ext":".png"},"80":{"title":"Groucho","name":"glasses-groucho","type":"glasses","level":"80","ext":".png"}}; 

return { data: data }; 

})(); 
