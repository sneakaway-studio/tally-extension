"use strict";

/*  BATTLE TEST
 ******************************************************************************/

window.BattleTest = (function() {
	// PRIVATE
	let DEBUG = Debug.ALL.BattleTest;


	function test(){
		try {
			// run test
		} catch (err) {
			console.error(err);
		}
	}



	// PUBLIC
	return {
		test: test,

	};
})();
