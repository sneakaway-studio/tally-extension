"use strict";

var Onboarding = (function() {

	// check status of most recent
	function check() {

	}


	// show a new chapter,
	function show(_chapter) {

	}



	// PUBLIC
	return {

	};
}());
