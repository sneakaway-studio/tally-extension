"use strict";

/*  BATTLE TEST
 ******************************************************************************/

window.BattleTest = (function() {
	// PRIVATE



	function test(){
		try {
			// run test
		} catch (err) {
			console.error(err);
		}
	}



	// PUBLIC
	return {
		test: test,

	};
})();
